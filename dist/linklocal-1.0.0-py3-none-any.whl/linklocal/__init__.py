"""LinkLocal package."""


